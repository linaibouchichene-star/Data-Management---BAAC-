Requirements 

pandas==2.3.3
numpy==1.26.4
streamlit==1.52.1
plotly==6.5.0

