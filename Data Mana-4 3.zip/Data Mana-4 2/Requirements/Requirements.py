Requirements 

pandas==2.3.3
numpy==1.26.4
streamlit==1.52.1
plotly==6.5.0
wordcloud==1.9.3
matplotlib==3.9.2
nltk==3.9.2
scikit-learn==1.5.2
Unidecode==1.3.8
