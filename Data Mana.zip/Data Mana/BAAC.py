import pandas as pd
import numpy as np

caract_2023 = pd.read_csv("caract-2023.csv", sep=";")
caract_2022 = pd.read_csv("caract-2022.csv", sep=";")

lieux_2023 = pd.read_csv("lieux-2023.csv", sep=";")
lieux_2022 = pd.read_csv("lieux-2022.csv", sep=";")

usagers_2023 = pd.read_csv("usagers-2023.csv", sep=";")
usagers_2022 = pd.read_csv("usagers-2022.csv", sep=";")

vehicules_2023 = pd.read_csv("vehicules-2023.csv", sep=";")
vehicules_2022 = pd.read_csv("vehicules-2022.csv", sep=";")

""" On effectue un diagnosic pour chaque csv pour savoir ce qu'il y a à nettoyer : 
--> modèle utilisé pour chaque csv et à adapter pour chaque table"""

"""Diagnostic tables caractéristiques 2022/2023"""
import pandas as pd
import numpy as np
import re

dfs = {"2023": caract_2023, "2022": caract_2022}

def diagnostic(df, year):
    print(f" DIAGNOSTIC {year}")
    # on affiche la taille de notre table 
    print(f" Nombre de lignes : {df.shape[0]}")
    print(f" Nombre de colonnes : {df.shape[1]}\n")
    
    # Le type de valeur par colonne
    print("Types des colonnes :")
    print(df.dtypes)
    print("\n")
    
    # Les valeurs manquantes par colonnes
    print("Valeurs manquantes :")
    print(df.isna().sum())
    print("\n")
    
    # On vérifie que les dates sont bien cohérentes entre elles
    print("Vérification jour/mois/an :")
    print("Valeurs jour hors 1–31 :", df[(df['jour'] < 1) | (df['jour'] > 31)].shape[0])
    print("Valeurs mois hors 1–12 :", df[(df['mois'] < 1) | (df['mois'] > 12)].shape[0])
    print("Année différente du fichier :", df[df['an'] != int(year)].shape[0])
    print("\n")
    
    #On vérifie la colonne des heures et minutes 
    bad_hrmn = df[~df['hrmn'].str.match(r'^\d{1,2}:\d{2}$', na=False)]
    print("Lignes hrmn incorrectes :", len(bad_hrmn))
    
    # On vérifie les colonnes latitute et longitudes voir si les données de géolocalisation sotn bien présente 
    print("Vérification lat/long :")
    df['lat'].astype(str).str.contains(",").sum()
    df['long'].astype(str).str.contains(",").sum()

    
    # détecte les virgules
    print("lat avec virgule :", df['lat'].astype(str).str.contains(",").sum())
    print("long avec virgule :", df['long'].astype(str).str.contains(",").sum())
    print("\n")
    
    
# on lance le diagnostic 
for y, df in dfs.items():
    diagnostic(df, y)

""" Nettoyage Caractéristiques 2022–2023"""
# Renommer Accident_Id
caract_2022 = caract_2022.rename(columns={"Accident_Id": "Num_Acc"})
caract_2023 = caract_2023.rename(columns={"Accident_Id": "Num_Acc"})

# Corriger lat/long
for df in [caract_2022, caract_2023]:
    df["lat"] = df["lat"].astype(str).str.replace(",", ".", regex=False).astype(float)
    df["long"] = df["long"].astype(str).str.replace(",", ".", regex=False).astype(float)

# Nettoyage adr
for df in [caract_2022, caract_2023]:
    df["adr"] = df["adr"].replace({"": np.nan, " ": np.nan})

# Découpage hrmn
def split_hrmn(df):
    df["heure"] = df["hrmn"].str.split(":").str[0].astype(int)
    df["minute"] = df["hrmn"].str.split(":").str[1].astype(int)
    return df

caract_2022 = split_hrmn(caract_2022)
caract_2023 = split_hrmn(caract_2023)


""" Diagnostic pour le nettoyage des Tables Lieux 2022 - 2023 """

dfs_lieux = {"2023": lieux_2023, "2022": lieux_2022}

def diagnostic_lieux(df, year):
    print(f"\n=== DIAGNOSTIC LIEUX {year} ===")

    # Taille
    print(f"- Nombre de lignes : {df.shape[0]}")
    print(f"- Nombre de colonnes : {df.shape[1]}\n")

    # Types
    print("Types des colonnes :")
    print(df.dtypes)
    print()

    # Valeurs manquantes
    print("Valeurs manquantes :")
    print(df.isna().sum())
    print()

    # Doublons Num_Acc
    print("Doublons Num_Acc :", df["Num_Acc"].duplicated().sum())

for year, df in dfs_lieux.items():
    diagnostic_lieux(df, year)

"""Nettoyage de la table lieux """

def nettoyer_lieux(df):
    df = df.copy()
    
    # Colonnes à nettoyer
    cols = ["voie", "v2", "nbv", "pr", "pr1", "lartpc", "larrout"]
    for col in cols:
        df[col] = df[col].replace({"": np.nan, " ": np.nan})

    # Convertir
    for col in ["voie", "v2", "nbv", "pr", "pr1", "larrout"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    # Supprimer colonne quasi vide
    if "lartpc" in df.columns:
        df = df.drop(columns=["lartpc"])

    # Plages
    plage = {
        "catr": (1, 9),
        "circ": (1, 9),
        "prof": (0, 9),
        "plan": (1, 9),
        "surf": (1, 7),
        "infra": (0, 9),
        "situ": (0, 9),
        "vma": (0, 130)
    }

    for col, (minv, maxv) in plage.items():
        df.loc[(df[col] < minv) | (df[col] > maxv), col] = np.nan

    return df

lieux_2022_clean = nettoyer_lieux(lieux_2022)
lieux_2023_clean = nettoyer_lieux(lieux_2023)


""" Diagnostic pour la Table usagers """



dfs_usagers = {"2023": usagers_2023, "2022": usagers_2022}


def diagnostic_usagers(df, year):
    print(f"\n=== DIAGNOSTIC USAGERS {year} ===\n")

    print(f"- Nombre de lignes : {df.shape[0]}")
    print(f"- Nombre de colonnes : {df.shape[1]}\n")

    print("Types des colonnes :")
    print(df.dtypes)
    print()

    print("Valeurs manquantes :")
    print(df.isna().sum())
    print()

    # Doublons
    print("Doublons Num_Acc + id_usager :", df.duplicated(subset=["Num_Acc", "id_usager"]).sum(), "\n")
    
    important_cols = ["sexe", "grav", "trajet", "locp", "actp", "place"]

    # Fonction pour tester sans TypeError
    def check_range_safe(df, col, min_val, max_val):
        if col in df.columns:
            # conversion sécurisée
            numeric_col = pd.to_numeric(df[col], errors="coerce")
            anomalies = numeric_col[(numeric_col < min_val) | (numeric_col > max_val)]
            print(f"{col} valeurs hors plage ({min_val}-{max_val}) :", anomalies.shape[0])

    check_range_safe(df, "sexe", 1, 2)
    check_range_safe(df, "grav", 1, 4)
    check_range_safe(df, "trajet", 1, 9)
    check_range_safe(df, "locp", 1, 9)
    check_range_safe(df, "place", 1, 9)
    check_range_safe(df, "actp", 1, 13)

    print("\nRecherche des codes aberrants (-1, 99, 999) :")
    for col in important_cols:
        if col in df.columns:
            numeric_col = pd.to_numeric(df[col], errors="coerce")
            anomalies = df[numeric_col.isin([-1, 99, 999])]
            print(f"{col} :", anomalies.shape[0])

    print("\nQualité des identifiants texte :")
    for col in ["id_usager", "id_vehicule", "num_veh"]:
        if col in df.columns:
            print(f"{col} valeurs vides :", df[col].isin(["", " ", "   "]).sum())

    print("\n--- Fin diagnostic ---\n")

# Lancer le diagnostic
for year, df in dfs_usagers.items():
    diagnostic_usagers(df, year)

"Nettoyage de la Table Usager 2022-2023"


def nettoyer_usagers(df):
    df = df.copy()

    plages = {
        "sexe": (1, 2),
        "grav": (1, 4),
        "trajet": (1, 9),
        "locp": (1, 9),
        "actp": (1, 13),
        "place": (1, 9)
    }

    aberrants = [-1, 0, 99, 999, "99", "0"]

    for col in df.columns:
        df[col] = df[col].replace(aberrants, np.nan)

    for col, (minv, maxv) in plages.items():
        df[col] = pd.to_numeric(df[col], errors="coerce")
        df.loc[(df[col] < minv) | (df[col] > maxv), col] = np.nan

    return df

usagers_2022_clean = nettoyer_usagers(usagers_2022)
usagers_2023_clean = nettoyer_usagers(usagers_2023)


""" Diagnostic pour les tables vehicules 2022/2023"""


dfs_vehicules = {"2023": vehicules_2023, "2022": vehicules_2022}



def diagnostic_vehicules(df, year):
    print(f"\n=== DIAGNOSTIC VEHICULES {year} ===\n")

    print(f"- Nombre de lignes : {df.shape[0]}")
    print(f"- Nombre de colonnes : {df.shape[1]}\n")

    print("Types des colonnes :")
    print(df.dtypes)
    print()

    print("Valeurs manquantes :")
    print(df.isna().sum())
    print()

    # Doublons sur identifiant véhicule par accident
    print("Doublons (Num_Acc + id_vehicule) :", 
          df.duplicated(subset=["Num_Acc", "id_vehicule"]).sum(), "\n")

    # Nettoyage des identifiants pour vérification
    for col in ["id_vehicule", "num_veh"]:
        df[col] = df[col].astype(str).str.replace("\xa0", "", regex=False)

    print("Identifiants vides :")
    for col in ["id_vehicule", "num_veh"]:
        print(f"{col} vides :", df[col].isin(["", " ", "   "]).sum())

    print("\n--- Vérification des plages ---")

    def check_range(col, min_val, max_val):
        if col in df.columns:
            numeric_col = pd.to_numeric(df[col], errors="ignore")
            anomalies = numeric_col[(numeric_col < min_val) | (numeric_col > max_val)]
            print(f"{col} hors plage ({min_val}-{max_val}) :", anomalies.shape[0])

    check_range("senc", 1, 3)
    check_range("catv", 1, 39)
    check_range("obs", 0, 9)
    check_range("obsm", 0, 9)
    check_range("choc", 1, 9)
    check_range("manv", 1, 18)
    check_range("motor", 1, 9)

    print("\nRecherche codes aberrants (-1, 99, 999) :")
    for col in ["catv", "obs", "obsm", "choc", "manv", "motor"]:
        if col in df.columns:
            numeric_col = pd.to_numeric(df[col], errors="coerce")
            anomalies = df[numeric_col.isin([-1, 99, 999])]
            print(f"{col} :", anomalies.shape[0])

    print("\n--- Fin diagnostic ---\n")

# Lancer diagnostic
for year, df in dfs_vehicules.items():
    diagnostic_vehicules(df, year)

"""Nettoyage des tables vehicules 2022/2023"""


def nettoyer_vehicules(df):
    df = df.copy()

    df["id_vehicule"] = df["id_vehicule"].astype(str).str.replace("\xa0", "")
    df["num_veh"] = df["num_veh"].astype(str).str.replace("\xa0", "")

    aberrants = [-1, 0, 99, 999, "99", "999", "0"]

    for col in df.columns:
        df[col] = df[col].replace(aberrants, np.nan)

    plages = {
        "senc": (1, 3),
        "catv": (1, 39),
        "obs": (0, 9),
        "obsm": (0, 9),
        "choc": (1, 9),
        "manv": (1, 18),
        "motor": (1, 9)
    }

    for col, (minv, maxv) in plages.items():
        df[col] = pd.to_numeric(df[col], errors="coerce")
        df.loc[(df[col] < minv) | (df[col] > maxv), col] = np.nan

    return df

vehicules_2022_clean = nettoyer_vehicules(vehicules_2022)
vehicules_2023_clean = nettoyer_vehicules(vehicules_2023)



""" Création de nouvelles variables"""
# on crée une nouvelle variable (colonne) qui indique le moment de la journée, cela peut-etre utile pour analyser les accidents

def periode_journee(h):
    if 0 <= h < 6:
        return "Nuit"
    elif 6 <= h < 12:
        return "Matin"
    elif 12 <= h < 18:
        return "Après-midi"
    else:
        return "Soir"

caract_2022["periode"] = caract_2022["heure"].apply(periode_journee)
caract_2023["periode"] = caract_2023["heure"].apply(periode_journee)

#une varibale qui s'implifie la gravité de l'accident 
def simplifier_grav(x):
    if x in [3, 4]:  # blessé grave ou tué
        return 1
    else:
        return 0

usagers_2022_clean["grav_simpl"] = usagers_2022_clean["grav"].apply(simplifier_grav)
usagers_2023_clean["grav_simpl"] = usagers_2023_clean["grav"].apply(simplifier_grav)

# on crée colonne pour l'age, et on sépare selon les tranches d'age 
usagers_2023_clean["age"] = 2023 - usagers_2023_clean["an_nais"]
usagers_2022_clean["age"] = 2022 - usagers_2022_clean["an_nais"]

def tranche_age(a):
    if pd.isna(a): 
        return None
    elif a < 18:
        return "Mineur"
    elif a < 25:
        return "18–24"
    elif a < 40:
        return "25–39"
    elif a < 60:
        return "40–59"
    else:
        return "60+"

usagers_2023_clean["tranche_age"] = usagers_2023_clean["age"].apply(tranche_age)
usagers_2022_clean["tranche_age"] = usagers_2022_clean["age"].apply(tranche_age)

# Merge final des tables 


"""retse à faire :
- supprimer des colonnes inutiles comme les secu dans usagé car quasi que des Nan 
et voir en focntion de l'appli qu'on veut faire on supp quoi d'autres """