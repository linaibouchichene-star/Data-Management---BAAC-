# =====================================================================
# IMPORTS
# =====================================================================
import pandas as pd
import numpy as np
import os
import re

# =====================================================================
# CHARGEMENT DES DONNÉES BRUTES 
# =====================================================================
caract_2023 = pd.read_csv("caract-2023.csv", sep=";")
lieux_2023 = pd.read_csv("lieux-2023.csv", sep=";")
usagers_2023 = pd.read_csv("usagers-2023.csv", sep=";")
vehicules_2023 = pd.read_csv("vehicules-2023.csv", sep=";")

# =====================================================================
# DIAGNOSTIC CARACTÉRISTIQUES 2023
# =====================================================================
def diagnostic(df, year):
    print(f"\n=== DIAGNOSTIC CARACT {year} ===")
    print(f"Nombre de lignes : {df.shape[0]}")
    print(f"Nombre de colonnes : {df.shape[1]}\n")
    print("Types des colonnes :")
    print(df.dtypes, "\n")
    print("Valeurs manquantes :")
    print(df.isna().sum(), "\n")

    print("Vérification jour/mois/an :")
    print("Jour hors plage :", df[(df['jour'] < 1) | (df['jour'] > 31)].shape[0])
    print("Mois hors plage :", df[(df['mois'] < 1) | (df['mois'] > 12)].shape[0])
    print("Année incohérente :", df[df['an'] != int(year)].shape[0], "\n")

    bad_hrmn = df[~df['hrmn'].astype(str).str.match(r'^\d{1,2}:\d{2}$', na=False)]
    print("Heures/minutes incorrectes :", len(bad_hrmn))

    print("lat avec virgule :", df['lat'].astype(str).str.contains(",").sum())
    print("long avec virgule :", df['long'].astype(str).str.contains(",").sum(), "\n")

diagnostic(caract_2023, "2023")

# =====================================================================
# NETTOYAGE CARACTÉRISTIQUES 2023
# =====================================================================
caract_2023 = caract_2023.rename(columns={"Accident_Id": "Num_Acc"})

# Corriger lat/long
caract_2023["lat"] = caract_2023["lat"].astype(str).str.replace(",", ".", regex=False).astype(float)
caract_2023["long"] = caract_2023["long"].astype(str).str.replace(",", ".", regex=False).astype(float)

# Nettoyage adr
caract_2023["adr"] = caract_2023["adr"].replace({"": np.nan, " ": np.nan})

# Découper hrmn
def split_hrmn(df):
    df["heure"] = df["hrmn"].str.split(":").str[0].astype(int)
    df["minute"] = df["hrmn"].str.split(":").str[1].astype(int)
    return df

caract_2023 = split_hrmn(caract_2023)

# =====================================================================
# DIAGNOSTIC LIEUX 2023
# =====================================================================
def diagnostic_lieux(df, year):
    print(f"\n=== DIAGNOSTIC LIEUX {year} ===")
    print(df.info())
    print("Valeurs manquantes :")
    print(df.isna().sum())
    print("Doublons Num_Acc :", df["Num_Acc"].duplicated().sum())

diagnostic_lieux(lieux_2023, "2023")

# =====================================================================
# NETTOYAGE LIEUX 2023
# =====================================================================
def nettoyer_lieux(df):
    df = df.copy()
    cols = ["voie", "v2", "nbv", "pr", "pr1", "lartpc", "larrout"]
    for col in cols:
        df[col] = df[col].replace({"": np.nan, " ": np.nan})

    for col in ["voie", "v2", "nbv", "pr", "pr1", "larrout"]:
        df[col] = pd.to_numeric(df[col], errors="coerce")

    if "lartpc" in df.columns:
        df = df.drop(columns=["lartpc"])

    plage = {
        "catr": (1, 9),
        "circ": (1, 9),
        "prof": (0, 9),
        "plan": (1, 9),
        "surf": (1, 7),
        "infra": (0, 9),
        "situ": (0, 9),
        "vma": (0, 130)
    }

    for col, (minv, maxv) in plage.items():
        df.loc[(df[col] < minv) | (df[col] > maxv), col] = np.nan

    return df

lieux_2023_clean = nettoyer_lieux(lieux_2023)

# =====================================================================
# DIAGNOSTIC USAGERS 2023
# =====================================================================
def diagnostic_usagers(df, year):
    print(f"\n=== DIAGNOSTIC USAGERS {year} ===\n")
    print(df.info())
    print("\nValeurs manquantes :\n", df.isna().sum())
    print("Doublons Num_Acc + id_usager :", df.duplicated(subset=["Num_Acc", "id_usager"]).sum(), "\n")

diagnostic_usagers(usagers_2023, "2023")

# =====================================================================
# NETTOYAGE USAGERS 2023
# =====================================================================
def nettoyer_usagers(df):
    df = df.copy()
    df["id_vehicule"] = df["id_vehicule"].astype(str).str.replace(" ", "").str.replace("\xa0", "")
    df["num_veh"] = df["num_veh"].astype(str).str.replace(" ", "").str.replace("\xa0", "")

    aberrants = [-1, 0, 99, 999, "99", "0"]

    for col in df.columns:
        df[col] = df[col].replace(aberrants, np.nan)

    plages = {
        "sexe": (1, 2),
        "grav": (1, 4),
        "trajet": (1, 9),
        "locp": (1, 9),
        "actp": (1, 13),
        "place": (1, 9)
    }

    for col, (minv, maxv) in plages.items():
        df[col] = pd.to_numeric(df[col], errors="coerce")
        df.loc[(df[col] < minv) | (df[col] > maxv), col] = np.nan

    return df

usagers_2023_clean = nettoyer_usagers(usagers_2023)

# =====================================================================
# DIAGNOSTIC VEHICULES 2023
# =====================================================================
def diagnostic_vehicules(df, year):
    print(f"\n=== DIAGNOSTIC VEHICULES {year} ===\n")
    print(df.info())
    print("Doublons Num_Acc + id_vehicule :", df.duplicated(subset=["Num_Acc", "id_vehicule"]).sum())

diagnostic_vehicules(vehicules_2023, "2023")

# =====================================================================
# NETTOYAGE VÉHICULES 2023
# =====================================================================
def nettoyer_vehicules(df):
    df = df.copy()
    df["id_vehicule"] = df["id_vehicule"].astype(str).str.replace(" ", "").str.replace("\xa0", "")
    df["num_veh"] = df["num_veh"].astype(str).str.replace(" ", "").str.replace("\xa0", "")

    aberrants = [-1, 0, 99, 999, "99", "999", "0"]

    for col in df.columns:
        df[col] = df[col].replace(aberrants, np.nan)

    plages = {
        "senc": (1, 3),
        "catv": (1, 39),
        "obs": (0, 9),
        "obsm": (0, 9),
        "choc": (1, 9),
        "manv": (1, 18),
        "motor": (1, 9)
    }

    for col, (minv, maxv) in plages.items():
        df[col] = pd.to_numeric(df[col], errors="coerce")
        df.loc[(df[col] < minv) | (df[col] > maxv), col] = np.nan

    return df

vehicules_2023_clean = nettoyer_vehicules(vehicules_2023)

# =====================================================================
# VARIABLES SUPPLÉMENTAIRES (2023 uniquement)
# =====================================================================
def periode_journee(h):
    if 0 <= h < 6:
        return "Nuit"
    elif 6 <= h < 12:
        return "Matin"
    elif 12 <= h < 18:
        return "Après-midi"
    else:
        return "Soir"

caract_2023["periode"] = caract_2023["heure"].apply(periode_journee)

def simplifier_grav(x):
    return 1 if x in [3, 4] else 0

usagers_2023_clean["grav_simpl"] = usagers_2023_clean["grav"].apply(simplifier_grav)
usagers_2023_clean["age"] = 2023 - usagers_2023_clean["an_nais"]

def tranche_age(a):
    if pd.isna(a): 
        return None
    elif a < 18:
        return "Mineur"
    elif a < 25:
        return "18–24"
    elif a < 40:
        return "25–39"
    elif a < 60:
        return "40–59"
    else:
        return "60+"

usagers_2023_clean["tranche_age"] = usagers_2023_clean["age"].apply(tranche_age)

# =====================================================================
# SUPPRESSION COLONNES INUTILES
# =====================================================================
usagers_2023_clean.drop(columns=["secu1", "secu2", "secu3"], errors="ignore", inplace=True)
vehicules_2023_clean.drop(columns=["occutc"], errors="ignore", inplace=True)
lieux_2023_clean.drop(columns=["v2", "pr1"], errors="ignore", inplace=True)
caract_2023.drop(columns=["adr"], errors="ignore", inplace=True)

# =====================================================================
# EXPORT FINAL 2023 UNIQUEMENT
# =====================================================================
os.makedirs("clean", exist_ok=True)

caract_2023.to_csv("clean/caract_2023_clean.csv", index=False)
lieux_2023_clean.to_csv("clean/lieux_2023_clean.csv", index=False)
usagers_2023_clean.to_csv("clean/usagers_2023_clean.csv", index=False)
vehicules_2023_clean.to_csv("clean/vehicules_2023_clean.csv", index=False)

# MERGE FINAL 2023
df_2023 = (
    caract_2023
        .merge(lieux_2023_clean, on="Num_Acc", how="left")
        .merge(vehicules_2023_clean, on="Num_Acc", how="left")
        .merge(usagers_2023_clean, on=["Num_Acc", "id_vehicule"], how="left")
)

df_2023.to_csv("clean/final_2023.csv", index=False)

print(df_2023[["Num_Acc", "id_vehicule", "age", "tranche_age", "grav_simpl"]].head())
