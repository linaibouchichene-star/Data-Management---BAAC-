import streamlit as st
import pandas as pd
import plotly.express as px
from folium.plugins import MarkerCluster
import folium
from streamlit_folium import st_folium

# -----------------------------------------------------
# CONFIG APP
# -----------------------------------------------------
st.set_page_config(page_title="Accidents Explorer 2.0", layout="wide")

# -----------------------------------------------------
# 🔐 LOGIN
# -----------------------------------------------------
def user_login():
    with st.sidebar.expander("🔐 Connexion", expanded=True):
        if "user_email" not in st.session_state:
            st.session_state["user_email"] = None

        if not st.session_state["user_email"]:
            email = st.text_input("Adresse e-mail :", placeholder="ex : nom@exemple.com")
            login_btn = st.button("Se connecter")

            if login_btn:
                if "@" in email and "." in email:
                    st.session_state["user_email"] = email
                    st.success("Bienvenue " + email)
                    st.rerun()
                else:
                    st.error("Adresse e-mail invalide.")
        else:
            st.success(f"Connecté : {st.session_state['user_email']}")
            if st.button("Se déconnecter"):
                st.session_state["user_email"] = None
                st.rerun()

# -----------------------------------------------------
# 🔄 LOAD DATA (UNIQUEMENT 2023)
# -----------------------------------------------------
@st.cache_data
def load_data():
    df_2023 = pd.read_csv("clean/final_2023.csv")

    df_2023 = df_2023.rename(columns={
        "long": "longitude",
        "lng": "longitude",
        "lon": "longitude",
        "Long": "longitude"
    })

    df_2023["annee"] = 2023
    return df_2023

df = load_data()

# -----------------------------------------------------
# 🏠 HOME PAGE
# -----------------------------------------------------
def show_home():
    st.markdown("""
        <div style='text-align:center; padding:40px;'>
            <h1>🚗 <span style='color:#0078ff'>Accidents Explorer 2023</span></h1>
            <p>Analyse des accidents routiers en France (année 2023 uniquement)</p>
        </div>
    """, unsafe_allow_html=True)

    email = st.text_input("Adresse e-mail :")
    if st.button("Se connecter"):
        if "@" in email and "." in email:
            st.session_state["user_email"] = email
            st.rerun()
        else:
            st.error("Adresse invalide.")

# -----------------------------------------------------
# 📁 PAGE 1 — Présentation
# -----------------------------------------------------
def dataset_page(df):
    st.header("📁 Présentation du dataset")

    col1, col2, col3 = st.columns(3)
    col1.metric("Nombre total d'accidents", len(df))
    col2.metric("Année", "2023")
    col3.metric("Variables", df.shape[1])

    st.subheader("Types de variables")
    st.write(pd.DataFrame(df.dtypes.astype(str), columns=["Type"]))

    st.subheader("Valeurs manquantes (%)")
    missing = (df.isna().mean() * 100).round(2)
    st.bar_chart(missing)

    st.subheader("Aperçu")
    st.dataframe(df.head())

# -----------------------------------------------------
# 📈 PAGE 2 — Visualisations
# -----------------------------------------------------
def viz_page(df):

    st.header("📈 Visualisations")

    colB, colC, colD = st.columns(3)

    sexe = colB.multiselect("Sexe", ["Homme", "Femme"], ["Homme", "Femme"])
    grav = colC.selectbox("Gravité", ["Tous", "Grave (1)", "Non grave (0)"])
    age = colD.multiselect(
        "Tranche d'âge",
        df["tranche_age"].dropna().unique(),
        df["tranche_age"].dropna().unique()
    )

    dff = df.copy()

    sexmap = {1: "Homme", 2: "Femme"}
    dff["sexe_label"] = dff["sexe"].replace(sexmap)
    dff = dff[dff["sexe_label"].isin(sexe)]

    if grav == "Grave (1)":
        dff = dff[dff["grav_simpl"] == 1]
    elif grav == "Non grave (0)":
        dff = dff[dff["grav_simpl"] == 0]

    dff = dff[dff["tranche_age"].isin(age)]

    # -- Charts --
    st.subheader("📊 Par tranche d'âge")
    st.plotly_chart(px.bar(dff, x="tranche_age", color="tranche_age"), use_container_width=True)

    st.subheader("👤 Par sexe")
    st.plotly_chart(px.pie(dff, names="sexe_label"), use_container_width=True)

    st.subheader("⏰ Par période")
    st.plotly_chart(px.bar(dff, x="periode", color="periode"), use_container_width=True)

    st.subheader("🩸 Gravité")
    st.plotly_chart(px.pie(dff, names="grav_simpl"), use_container_width=True)

    st.subheader("🔥 Heatmap")
    st.plotly_chart(px.density_heatmap(dff, x="periode", y="tranche_age"), use_container_width=True)

# -----------------------------------------------------
# 🗺️ PAGE 3 — Carte interactive
# -----------------------------------------------------
def map_page(df):

    st.header("🗺️ Carte des accidents 2023")

    if "lat" not in df.columns or "longitude" not in df.columns:
        st.error("Colonnes GPS manquantes.")
        return

    gps_df = df.dropna(subset=["lat", "longitude"])

    if len(gps_df) > 2000:
        gps_df = gps_df.sample(2000)   # 🔥 Évite le freeze automatique

    m = folium.Map(location=[46.5, 2.5], zoom_start=6, tiles="CartoDB Positron")
    cluster = MarkerCluster().add_to(m)

    for _, row in gps_df.iterrows():
        grav = "Grave" if row["grav_simpl"] == 1 else "Non grave"
        popup = f"""
            <b>Tranche d'âge:</b> {row['tranche_age']}<br>
            <b>Sexe:</b> {row['sexe']}<br>
            <b>Gravité:</b> {grav}
        """
        folium.Marker([row["lat"], row["longitude"]], popup=popup).add_to(cluster)

    st_folium(m, width=900, height=600)

# -----------------------------------------------------
# MAIN APP
# -----------------------------------------------------
def main_app():
    user_login()

    st.title("🚗 Accidents Explorer — Analyse 2023")

    tabs = st.tabs(["📁 Dataset", "📈 Visualisations", "🗺️ Carte"])

    with tabs[0]:
        dataset_page(df)

    with tabs[1]:
        viz_page(df)

    with tabs[2]:
        map_page(df)

# -----------------------------------------------------
# START
# -----------------------------------------------------
if "user_email" not in st.session_state or not st.session_state["user_email"]:
    show_home()
else:
    main_app()
