# ======================================================
# 📌 ACCIDENTS EXPLORER — VERSION FINALE OPTIMISÉE
# ======================================================

import streamlit as st
import pandas as pd
import plotly.express as px
from folium.plugins import MarkerCluster
import folium
from streamlit_folium import st_folium

# -----------------------------------------------------
# CONFIG
# -----------------------------------------------------
st.set_page_config(page_title="Accidents Explorer 2023", layout="wide")


# -----------------------------------------------------
# 🔐 LOGIN
# -----------------------------------------------------
def sidebar_login():
    with st.sidebar.expander("🔐 Connexion", expanded=True):
        if "user" not in st.session_state:
            st.session_state.user = None

        if not st.session_state.user:
            mail = st.text_input("Adresse e-mail :")
            if st.button("Se connecter"):
                if "@" in mail and "." in mail:
                    st.session_state.user = mail
                    st.rerun()
                else:
                    st.error("Adresse invalide.")
        else:
            st.success(f"Connecté : {st.session_state.user}")
            if st.button("Se déconnecter"):
                st.session_state.user = None
                st.rerun()


# -----------------------------------------------------
# 📁 LOAD DATA (FINAL_2023)
# -----------------------------------------------------
@st.cache_data
def load_data():
    df = pd.read_csv("clean/final_2023.csv")

    # Fix longitude naming
    df = df.rename(columns={
        "long": "longitude",
        "lon": "longitude",
        "lng": "longitude",
        "Long": "longitude"
    })

    # Fix sexe label
    df["sexe"] = pd.to_numeric(df["sexe"], errors="coerce").astype("Int64")
    df["sexe_label"] = df["sexe"].map({1: "Homme", 2: "Femme"})

    return df


df = load_data()


# -----------------------------------------------------
# 🏠 PAGE : Dataset
# -----------------------------------------------------
def page_dataset(df):

    st.title("📁 Présentation du Dataset")

    col1, col2, col3 = st.columns(3)
    col1.metric("Nombre d'accidents", len(df))
    col2.metric("Année", "2023")
    col3.metric("Variables", df.shape[1])

    st.subheader("Types des variables")
    st.write(df.dtypes.astype(str))

    st.subheader("Valeurs manquantes (%)")
    st.bar_chart((df.isna().mean() * 100).round(2))

    st.subheader("Aperçu du dataset")
    st.dataframe(df.head())

    st.subheader("Statistiques descriptives")
    st.write(df.describe(include="all"))


# -----------------------------------------------------
# 📈 PAGE : Visualisations
# -----------------------------------------------------
def page_viz(df):

    st.title("📈 Visualisations interactives (2023)")

    # ------------------------------
    # ÉCHANTILLONNAGE AUTOMATIQUE
    # ------------------------------
    if len(df) > 30000:
        df = df.sample(30000, random_state=42)

    # ------------------------------
    # 🔎 Filtres
    # ------------------------------
    col1, col2, col3 = st.columns(3)

    sexe = col1.multiselect("Sexe", ["Homme", "Femme"], ["Homme", "Femme"])
    grav = col2.selectbox("Gravité", ["Tous", "Grave", "Non grave"])
    ages = col3.multiselect(
        "Tranche d'âge",
        df["tranche_age"].dropna().unique(),
        df["tranche_age"].dropna().unique(),
    )

    dff = df.copy()

    # Filters
    dff = dff[dff["sexe_label"].isin(sexe)]

    if grav == "Grave":
        dff = dff[dff["grav_simpl"] == 1]
    elif grav == "Non grave":
        dff = dff[dff["grav_simpl"] == 0]

    dff = dff[dff["tranche_age"].isin(ages)]

    # ------------------------------
    # GRAPHIQUES OBLIGATOIRES
    # ------------------------------

    st.subheader("📊 Répartition par tranche d'âge")
    st.plotly_chart(px.bar(dff, x="tranche_age", color="tranche_age"), use_container_width=True)

    st.subheader("👤 Répartition par sexe")
    st.plotly_chart(px.pie(dff, names="sexe_label"), use_container_width=True)

    st.subheader("⏰ Accidents par période de la journée")
    st.plotly_chart(px.bar(dff, x="periode", color="periode"), use_container_width=True)

    st.subheader("🩸 Gravité des accidents")
    st.plotly_chart(px.pie(dff, names="grav_simpl"), use_container_width=True)

    st.subheader("🔥 Heatmap : Période × Âge")
    st.plotly_chart(px.density_heatmap(dff, x="periode", y="tranche_age"), use_container_width=True)


# -----------------------------------------------------
# 🗺️ PAGE : Carte
# -----------------------------------------------------
def page_map(df):

    st.title("🗺️ Carte interactive des accidents")

    if "lat" not in df.columns or "longitude" not in df.columns:
        st.error("Colonnes GPS manquantes.")
        return

    gps_df = df.dropna(subset=["lat", "longitude"])

    if len(gps_df) > 2000:
        gps_df = gps_df.sample(2000)

    m = folium.Map(location=[46.5, 2.5], zoom_start=6, tiles="CartoDB Positron")
    cluster = MarkerCluster().add_to(m)

    for _, row in gps_df.iterrows():
        folium.Marker(
            [row["lat"], row["longitude"]],
            popup=f"""
                <b>Âge:</b> {row['tranche_age']}<br>
                <b>Sexe:</b> {row['sexe_label']}<br>
                <b>Gravité:</b> {row['grav_simpl']}
            """
        ).add_to(cluster)

    st_folium(m, width=900, height=600)


# -----------------------------------------------------
# MAIN
# -----------------------------------------------------
def main():

    sidebar_login()

    page = st.sidebar.radio("Navigation", [
        "📁 Dataset",
        "📈 Visualisations",
        "🗺️ Carte"
    ])

    if page == "📁 Dataset":
        page_dataset(df)
    elif page == "📈 Visualisations":
        page_viz(df)
    elif page == "🗺️ Carte":
        page_map(df)


# -----------------------------------------------------
# START
# -----------------------------------------------------
if "user" not in st.session_state or st.session_state.user is None:
    st.write("Connectez-vous dans la barre latérale pour accéder à l'application.")
    sidebar_login()
else:
    main()
